﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_Борисов
{
    internal class Задание_1
    {
    }
}
